// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;

// ---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner) : TForm(Owner) {
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender) {
	Close();
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::FormCreate(TObject *Sender) {
	for (int i = 1; i < SG1->RowCount; i++)
		SG1->Cells[0][i] = i;
	for (int i = 1; i < SG1->ColCount; i++)
		SG1->Cells[i][0] = i;
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Edit1Change(TObject *Sender) {
	int k;
	if (Edit1->Text != "") {
		k = StrToInt(Edit1->Text);
		if (k < 2)
			k = 2;
		SG1->RowCount = k;
		for (int i = 1; i < SG1->RowCount; i++)
			SG1->Cells[0][i] = i;
	}
}

// ---------------------------------------------------------------------------
void __fastcall TForm2::Edit2Change(TObject *Sender) {
	int k;
	if (Edit2->Text != "") {
		k = StrToInt(Edit2->Text);
		if (k < 2)
			k = 2;
		SG1->ColCount = k;
		for (int i = 1; i < SG1->ColCount; i++)
			SG1->Cells[i][0] = i;
	}
}
// ---------------------------------------------------------------------------
