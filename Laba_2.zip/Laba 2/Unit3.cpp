// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include "Unit2.h"
#include "Unit3.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;

bool isPrime(int k) {

	double n = (int) k;
	for (int i = 2; i <= sqrt(abs(n)); i++) {
		int s = (double) n;
		if (s % i == 0) {
			return false;

		}
	}

	return true;
}

// ---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner) : TForm(Owner) {
}
// ---------------------------------------------------------------------------

void __fastcall TForm3::FormActivate(TObject *Sender) {
	int a[100];
	int k = -1;

	for (int i = 1; i < Form2->SG1->RowCount; i++) {
		for (int j = 1; j < Form2->SG1->ColCount; j++) {
			int ch = StrToInt(Form2->SG1->Cells[j][i]);
			if (isPrime(ch)) {
				k++;
				a[k] = ch;

			}
		}
	}
	UnicodeString s;
	for (int i = 0; i <= k; i++) {
		s += IntToStr(a[i]) + " ";
	}
	Result->Text = s;

    	for (int i = 1; i < Form2->SG1->RowCount; i++) {
		 for (int j = 1; j < Form2->SG1->ColCount; j++) {
			int ph = StrToInt(Form2->SG1->Cells[j][i]);
			if (ph < 0) {
				Bool->Text = "��";
				break;
			}
		}
	}


}

// ---------------------------------------------------------------------------

/*
 bool flag = 1;
 double n = (int) k;
 for (int i = 2; i<n; i++) {
 int s = (double) n;
 if (s % i == 0) {


 }
 }

 return true;
 */
void __fastcall TForm3::Button1Click(TObject *Sender) {
	Close();
}
// ---------------------------------------------------------------------------

/*
 if (isPrime(StrToInt(Form2->SG1->Cells[j][i]))) {
 // k++;
 //a[k] = StrToFloat(Form2->SG1->Cells[j][i])


 }
 */
