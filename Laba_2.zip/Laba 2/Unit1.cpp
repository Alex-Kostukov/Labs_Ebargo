// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "About.h"
#include "Unit2.h"
#include "Unit3.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

// ---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) : TForm(Owner) {
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::N2Click(TObject *Sender) {
	Close();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::N7Click(TObject *Sender) {
	AboutBox->ShowModal();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::N4Click(TObject *Sender) {
	Form2->Show();
}

// ---------------------------------------------------------------------------
void __fastcall TForm1::N5Click(TObject *Sender) {
	Form3->Show();
}
// ---------------------------------------------------------------------------
